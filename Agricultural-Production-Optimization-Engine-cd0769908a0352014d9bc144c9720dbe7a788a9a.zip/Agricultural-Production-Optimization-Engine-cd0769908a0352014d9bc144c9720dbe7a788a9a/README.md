# Agricultural-Production-Optimization-Engine
This Project focuses on building a predictive model so as to suggest the most suitable crops to grow, based on the nature of soil and the given climatic conditions.
